package Interfaz;

import java.util.Scanner;

import Dominio.Album;
import Dominio.Figurita;
import Dominio.Sobre;

public class Interfaz {

	private static Album album2026 = new Album();
	private static Scanner teclado = new Scanner(System.in);

	public static void main(String[] args) {

		Menum menuOpciones[] = Menum.values();
		Menum opcionElegida = null;

		do {

			System.out.println("=====================================\n");
			System.out.println("SISTEMA FIGURITAS MUNDIAL DE FÚTBOL 2026\n");
			System.out.println("=====================================\n");

			mostrarOpciones(menuOpciones);

			opcionElegida = elegirOpcion(menuOpciones, teclado);

			ejecutarOpcion(opcionElegida);

		} while (opcionElegida != Menum.SALIR);

		teclado.close();
	}

	private static void ejecutarOpcion(Menum opcionElegida) {

		switch (opcionElegida) {
		case INICIAR_ALBUM:
			System.out.println("\n INICIALIZAMOS EL ALBUM");
			album2026.inicializarAlbum();
			break;
		case COMPRAR_SOBRE:

			if (album2026.getFiguritasPegadas() == null) {
				System.out.println("\n PRIMERO SE DEBE INICIALIZAR EL ALBUM");
			} else {
				System.out.println("\n SE COMPRA 1 SOBRE");

				album2026.comprarSobre();

				Sobre nuevoSobre = album2026.getSobre();

				System.out.println(album2026.getSobre().toString());

				album2026.pegarFiguritas(nuevoSobre);
			}

			break;
		case INTERCAMBIAR_FIGURITAS:

			if (album2026.getFiguritasPegadas() == null) {
				System.out.println("\n PRIMERO SE DEBE INICIALIZAR EL ALBUM");
			} else if (album2026.getCantidadRepetidas() != 0) {
				System.out.println("\n ESTAS SON SUS FIGURITAS REPETIDAS:");

				for (int i = 0; i < album2026.getCantidadRepetidas(); i++) {
					System.out.println((i + 1) + " - " + album2026.getFiguritasRepetidas()[i].getCodigo());
				}

				System.out.println("Indique que figurita desea intercambiar:");

				int figuritaElegida = teclado.nextInt();
				Figurita figuritaAIntercambiar = album2026.getFiguritasRepetidas()[figuritaElegida - 1];

				Figurita figuritaNueva = album2026.intercambiarFiguritas(figuritaAIntercambiar);
				System.out.println(figuritaAIntercambiar + "\n intercambiada por la \n" + figuritaNueva);

			} else {
				System.out.println("\n USTED NO TIENE FIGURITAS REPETIDAS TODAVIA");
			}
			break;
		case VISUALIZAR_ALBUM:

			if (album2026.getFiguritasPegadas() == null) {
				System.out.println("\n PRIMERO SE DEBE INICIALIZAR EL ALBUM");
			} else {

				for (int i = 0; i < album2026.getCantidadPegadas(); i++) {
					System.out.println((i + 1) + " - " + album2026.ordenarFiguritas()[i].getCodigo());
				}
			}

			break;
		case SALIR:
			System.out.println("\n Saliendo...");

			break;

		default:
			System.out.println("\n OPCION INVALIDA");

		}
	}

	private static Menum elegirOpcion(Menum[] menuOpciones, Scanner teclado) {
		Menum opcionElegida = Menum.OPCION_INVALIDA;

		int opcionSeleccionada = teclado.nextInt();

		if (opcionSeleccionada >= 1 && opcionSeleccionada < 6) {
			opcionElegida = menuOpciones[opcionSeleccionada - 1];
		}
		return opcionElegida;
	}

	private static void mostrarOpciones(Menum[] menuOpciones) {
		for (int i = 0; i < menuOpciones.length - 1; i++) {
			System.out.println(menuOpciones[i]);
		}
	}

}
