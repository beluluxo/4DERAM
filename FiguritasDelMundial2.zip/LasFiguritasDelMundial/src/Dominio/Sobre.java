package Dominio;

public class Sobre {

private Figuritas[] sobre = new Figuritas[5];	

public Sobre () {	
}


////TENEMOS ESTOS 2 METODOS PARA GENERAR FIGURITAS////

//ESTE A PARTIR DE LAS FIGURITAS///

/*public void generarFiguritas() {
	
	for (int i = 0; i < sobre.length; i++) {
		
	int numeroSeleccion = (int)(Math.random() * Seleccion.values().length);
	int numeroJugador = (int) ((Math.random() * 22) +1);
	
	
	}
}

//ESTE A PARTIR DEL ALBUM QUE "CONTIENE A TODAS LAS FIGURITAS// RESUELVAN !!!!
 
public void generarFiguritas(Figuritas[] album) {

        for (int i = 0; i < sobre.length; i++) {

            int indice = (int)(Math.random() * album.length);

            sobre[i] = album[indice];
        }
    }

    public Figuritas[] getSobre() {
        return sobre;
    }
}
*/



}
