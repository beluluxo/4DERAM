package Dominio;

public class Album {

	// A
	private final static int TOTAL_DE_FIGURITAS_DEL_ALBUM = 1056;
	private Figuritas[] figuritasPegadas;
	private Figuritas[] figuritasRepetidas;
	private int cantidadPegadas;
	private int cantidadRepetidas;

	// C
	public Album() {
		this.cantidadPegadas = 0;
		this.cantidadRepetidas = 0;
	}

	// M
	public void inicializarAlbum() { // Debe preparar la estructura de datos que alojará las figuritas.
		figuritasPegadas = new Figuritas[TOTAL_DE_FIGURITAS_DEL_ALBUM];
		figuritasRepetidas = new Figuritas[TOTAL_DE_FIGURITAS_DEL_ALBUM * 2];
	}

	public void comprarSobre() { // TIENE QUE SER SOBRE //Simula la compra devolviendo un objeto Sobre con 5
   					           // figuritas generadas de forma aleatoria

		return;
	}

	
	public void pegarFiguritas(Sobre sobre) { // Recibe un sobre e intenta pegar cada una de sus figuritas en el álbum.
												// Si la figurita ya se encontraba pegada
												// previamente, deberá ser almacenada en el arreglo de
												// figuritasRepetidas.

	}

	public boolean elAlbumEstaCompleto() {
		return false;
	}

	public double calcularPorcentajeCompletado() {
		return 0.0;
	}

	public int obtenerCantidadRepetidas() {
		return -1;
	}

	public Figuritas[] getFiguritasPegadas() {
		return figuritasPegadas;
	}

	public void setFiguritasPegadas(Figuritas[] figuritasPegadas) {
		this.figuritasPegadas = figuritasPegadas;
	}

	public int getCantidadPegadas() {
		return cantidadPegadas;
	}

	public void setCantidadPegadas(int cantidadPegadas) {
		this.cantidadPegadas = cantidadPegadas;
	}

	public int getCantidadRepetidas() {
		return cantidadRepetidas;
	}

	public void setCantidadRepetidas(int cantidadRepetidas) {
		this.cantidadRepetidas = cantidadRepetidas;
	}

}
